from distutils import cmd


cmd{/home/jonas/Desktop/PYTHON/Cubing/A05.py}