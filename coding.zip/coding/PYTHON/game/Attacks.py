swing = {
  "damage": 150,
  "crit1.5": 15%,
  "crit2": 5%
}
Jab = {
  "damage": 120,
  "crit1.5": 50%,
  "crit2": 10%
}
attack = {
  "damage": 150,
  "crit1.5": 15%,
  "crit2": 5%
}
thisdict = {
  "damage": 150,
  "crit1.5": 15%,
  "crit2": 5%
}