print("Knight Stats:           Archer Stats:
        HP - 850                  HP - 55
       
       Swing                     Power Bow
      Damage - 150              Damage - 200
     1.5x Crit - 15%           1.5x Crit - 25%
      2x Crit - 5%             2x Crit - 10%

       Jab                       
      Damage 120                 Damage - 160
    1.5% Crit - 50%
    2x Crit - 10%

       Melee - 2                 Range - 0
    Turns to Attack            Turns to attack
    Ability - Shield. 
    25% Chance to Block
    Attack if Jab was Last Used")
120 + 33.75 + 15 = 168.75
48 + 80 + 24 = 152